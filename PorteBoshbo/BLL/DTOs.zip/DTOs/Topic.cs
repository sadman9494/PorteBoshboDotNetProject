﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
    public class Topic
    {
        public int TopicId { get; set; }
        public string TopicName { get; set; }
        public EducationLevel EducationLevel { get; set; }
        public Department Department { get; set; }
        public Course Course { get; set; }

    }
}
