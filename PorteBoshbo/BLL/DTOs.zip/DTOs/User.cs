﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        //public string PasswordConfirmed { get; set; }
        public string Role { get; set;}
        public float Balance { get; set; }
        //public bool IsStudent { get; set; }
        //public bool IsTeacher { get; set; }
        public List<Payment> ReceivedPayments { get; set; }
        public List<Payment> PaidPayments { get; set; }
        public List<Topic> Topics { get; set; }
        public Department Department { get; set; }
        public EducationLevel EducationLevel { get; set; }
        public List<Review> SubmittedReviews { get; set; }
        public List<Review> TeacherReviews { get; set; }

    }
}
