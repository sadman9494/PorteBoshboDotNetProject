﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
    public class Payment
    {
        public int PaymentnId { get; set; }
        public User Teacher { get; set; }
        public User Student { get; set; }
        public float Amount { get; set; }
        public string PaymentMethod { get; set; }
    }
}
