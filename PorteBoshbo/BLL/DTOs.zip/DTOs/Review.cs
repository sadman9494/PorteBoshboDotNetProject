﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs
{
    public class Review
    {
        public int ReviewId { get; set; }
        public string ReviewText { get; set; }
        public float Rating { get; set; }
        public User Teacher { get; set; }
        public User Student { get; set; }
        public Topic Topic { get; set; }
    }
}
